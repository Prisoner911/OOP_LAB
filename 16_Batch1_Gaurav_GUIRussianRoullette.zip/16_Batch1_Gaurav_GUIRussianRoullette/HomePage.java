

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class HomePage implements ActionListener{

	  public JButton sBtn;
	  public JButton rBtn;
	  public JLabel gameTitle;
	    
	    JFrame frame = new JFrame();
	  HomePage(){

	      // Initialize components
	      gameTitle = new JLabel();
	      gameTitle.setText("Russian Roulette");
	      gameTitle.setFont(new Font("Arial",Font.BOLD, 50));
	      gameTitle.setVerticalAlignment(JLabel.TOP);
	      gameTitle.setHorizontalAlignment(JLabel.CENTER);
	      gameTitle.setBounds(0,50,900,50);
		  
	      
	      
	      sBtn = new JButton();
	      sBtn.addActionListener(this);
	      sBtn.setText("START");
	      sBtn.setFont(new Font("Arial",Font.PLAIN,20));
	      sBtn.setBackground(new Color(74, 189, 58));
	      sBtn.setForeground(Color.white);
	      sBtn.setBounds(350,150,150,50);
	      sBtn.setHorizontalAlignment(JButton.CENTER);
	      sBtn.setBorder(BorderFactory.createEtchedBorder());
		  sBtn.setFocusable(false);
		  
	      rBtn = new JButton();
	      rBtn.addActionListener(this);
	      rBtn.setText("RULES");
	      rBtn.setFont(new Font("Arial",Font.PLAIN,20));
	      rBtn.setBackground(new Color(212, 188, 95));
	      rBtn.setForeground(Color.white);
	      rBtn.setBounds(350,250,150,50);
	      rBtn.setHorizontalAlignment(JButton.CENTER);
	      rBtn.setBorder(BorderFactory.createEtchedBorder());
		  rBtn.setFocusable(false);
	      
	      
	      // Set up the JFrame
		  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		  frame.setTitle("Russian Roulette");
	      frame.setSize(900,600);
	      frame.setResizable(false);
	      frame.setVisible(true);
	      frame.setLayout(null);
	      frame.add(gameTitle);
	      frame.add(sBtn);
	      frame.add(rBtn);
	  }
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == sBtn) {
			frame.dispose();
			GameScreen gScreen = new GameScreen();
		}
		
		else if (e.getSource() == rBtn) {
			frame.dispose();
			RulesPage rPage = new RulesPage();
		}
		
	}
	 
}
