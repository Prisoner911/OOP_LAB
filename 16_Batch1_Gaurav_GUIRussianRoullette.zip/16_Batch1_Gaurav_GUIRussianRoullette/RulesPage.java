

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class RulesPage implements ActionListener{

	JFrame frame = new JFrame();
	JButton back = new JButton();
	RulesPage(){
		
	      JLabel gameTitle = new JLabel();
	      gameTitle.setText("Russian Roulette");
	      gameTitle.setFont(new Font("Arial",Font.BOLD, 50));
	      gameTitle.setVerticalAlignment(JLabel.TOP);
	      gameTitle.setHorizontalAlignment(JLabel.CENTER);
	      gameTitle.setBounds(0,50,900,50);
		
		
	      back.setText("Back");
	      back.setBackground(new Color(252, 71, 71));
	      back.setBounds(0,0,150,50);
	      back.setFocusable(false);
	      back.setFont(new Font("Arial",Font.PLAIN,20));
	      back.setBorder(BorderFactory.createEtchedBorder());
	      back.addActionListener(this);
	      
	      JLabel rules = new JLabel();
	      rules.setText("<html><body style='width: 100%; padding: 10px;'>"
	                + "<ul style='list-style-type: disc;'>"
	                + "<li style='margin-bottom: 10px;'>Prize pool of $50,000</li>"
	                + "<li style='margin-bottom: 10px;'>One bullet is randomly entered in one of the 6 chambers.</li>"
	                + "<li style='margin-bottom: 10px;'>Player and dealer will take turns to shoot.</li>"
	                + "<li style='margin-bottom: 10px;'>You will decide whether to shoot the dealer or yourself.</li>"
	                + "<li style='margin-bottom: 10px;'>If you choose to shoot yourslef and you are safe, $5,000 will be added to your prize pool.</li>"
	                + "</ul>");
	      rules.setFont(new Font("Arial", Font.PLAIN, 20));  // Optional: Set font size
	      rules.setBounds(50, 150, 800, 300);  // Set position and size of the label
	      
	      
	      
		  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		  frame.setTitle("Russian Roulette");
	      frame.setSize(900,600);
	      frame.setResizable(false);
	      frame.setVisible(true);
	      frame.setLayout(null);
	      frame.add(gameTitle);
	      frame.add(back);
	      frame.add(rules);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		if(e.getSource() == back) {
			frame.dispose();
			new HomePage();
		}
	}
}
