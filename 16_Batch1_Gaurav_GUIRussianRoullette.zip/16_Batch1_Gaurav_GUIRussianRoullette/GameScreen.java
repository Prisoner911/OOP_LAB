
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.Timer;

public class GameScreen implements ActionListener {

    private JButton shootYourselfButton;
    private JButton shootDealerButton;
    private int bulletPosition;
    private int currentPosition;
    private int prize;
    private boolean gameOver;
    private Random random;
    public int turn = 0; // 0 for player, 1 for dealer
    public String message;

    JLabel dealer, player;
    JLabel dealerTxt, playerTxt;
    JFrame frame = new JFrame();
    JLabel shootDealerGun, shootPlayerGun;
    JLabel shootDealerGun1, shootPlayerGun1;

    JLabel shootDealerGunEmpty, shootPlayerGunEmpty;
    JLabel shootDealerGunEmpty1, shootPlayerGunEmpty1;
    JLabel prizePool, winSc, lostSc, blkSc;
    JLabel dealerSafeStat, playerSafeStat;
    JButton restartBtn;
    JLabel stat;

    GameScreen() {

        // Initialize game variables
        random = new Random();
        prize = 50000;
        bulletPosition = random.nextInt(6) + 1; // Randomly place the bullet in one chamber
        currentPosition = random.nextInt(6) + 1; // Starting position of the revolver
        if(bulletPosition == 6){
            bulletPosition = 0;
        }
        gameOver = false;
        System.out.println("Bullet pos : " + bulletPosition);
        System.out.println("Current pos : " + currentPosition);



        stat = new JLabel();
        stat.setBounds(350,300,900,50);
        stat.setFont(new Font("Arial", Font.PLAIN,20));
        stat.setVisible(false);

        restartBtn = new JButton();
        restartBtn = new JButton();
        restartBtn.addActionListener(this);
        restartBtn.setText("Restart");
        restartBtn.setFont(new Font("Arial", Font.PLAIN, 20));
        restartBtn.setBackground(new Color(191, 168, 86));
        restartBtn.setForeground(Color.black);
        restartBtn.setBounds(350, 450, 150, 50);
        restartBtn.setHorizontalAlignment(JButton.CENTER);
        restartBtn.setBorder(BorderFactory.createEtchedBorder());
        restartBtn.setFocusable(false);
        restartBtn.setVisible(false);

        blkSc = new JLabel();
        blkSc.setBackground(new Color(0, 0, 0, 128));
        blkSc.setBounds(0, 0, 900, 600);
        blkSc.setOpaque(true);
        blkSc.setVisible(false);

        prizePool = new JLabel();
        prizePool.setText("Current Prize Pool : $" + prize);
        prizePool.setBounds(280, 0, 900, 50);
        prizePool.setFont(new Font("Arial", Font.BOLD, 25));
        prizePool.setForeground(new Color(191, 168, 86));

        dealerSafeStat = new JLabel();
        dealerSafeStat.setText("Dealer is safe.");
        dealerSafeStat.setFont(new Font("Arial", Font.PLAIN, 20));
        dealerSafeStat.setBounds(380, 50, 200, 50);
        dealerSafeStat.setVisible(false);

        winSc = new JLabel();
        winSc.setBackground(new Color(93, 201, 98));
        winSc.setOpaque(true);

        winSc.setBounds(0, 200, 900, 200);
        winSc.setHorizontalAlignment(JLabel.CENTER);
        winSc.setVerticalAlignment(JLabel.CENTER);
        winSc.setFont(new Font("Arial", Font.BOLD, 40));
        winSc.setVisible(false);

        lostSc = new JLabel();
        lostSc.setBackground(new Color(199, 78, 78));
        lostSc.setOpaque(true);
        lostSc.setText("You Lost");
        lostSc.setBounds(0, 200, 900, 200);
        lostSc.setHorizontalAlignment(JLabel.CENTER);
        lostSc.setVerticalAlignment(JLabel.CENTER);
        lostSc.setFont(new Font("Arial", Font.BOLD, 40));
        lostSc.setVisible(false);

        shootYourselfButton = new JButton();
        shootYourselfButton.addActionListener(this);
        shootYourselfButton.setText("Shoot Yourself");
        shootYourselfButton.setFont(new Font("Arial", Font.PLAIN, 20));
        shootYourselfButton.setBackground(new Color(86, 184, 191));
        shootYourselfButton.setForeground(Color.black);
        shootYourselfButton.setBounds(350, 380, 150, 50);
        shootYourselfButton.setHorizontalAlignment(JButton.CENTER);
        shootYourselfButton.setBorder(BorderFactory.createEtchedBorder());
        shootYourselfButton.setFocusable(false);

        shootDealerButton = new JButton();
        shootDealerButton.addActionListener(this);
        shootDealerButton.setText("Shoot Dealer");
        shootDealerButton.setFont(new Font("Arial", Font.PLAIN, 20));
        shootDealerButton.setBackground(new Color(86, 184, 191));
        shootDealerButton.setForeground(Color.black);
        shootDealerButton.setBounds(350, 450, 150, 50);
        shootDealerButton.setHorizontalAlignment(JButton.CENTER);
        shootDealerButton.setBorder(BorderFactory.createEtchedBorder());
        shootDealerButton.setFocusable(false);

        ImageIcon dealerImage = new ImageIcon(getClass().getResource("/dealer.png"));
        dealer = new JLabel(dealerImage);
        dealer.setBounds(20, 100, 150, 150);
        dealerTxt = new JLabel("DEALER");
        dealerTxt.setBounds(30, 180, 150, 150);
        dealerTxt.setFont(new Font("Arial", Font.PLAIN, 20));
        dealerTxt.setHorizontalTextPosition(JLabel.CENTER);

        ImageIcon playerImage = new ImageIcon(getClass().getResource("/player1_1.png"));
        player = new JLabel(playerImage);
        player.setBounds(700, 90, 150, 150);
        playerTxt = new JLabel("YOU");
        playerTxt.setBounds(750, 180, 150, 150);
        playerTxt.setFont(new Font("Arial", Font.PLAIN, 20));
        playerTxt.setHorizontalTextPosition(JLabel.CENTER);

        ImageIcon dealerGun = new ImageIcon(getClass().getResource("/gun1C5_.png"));
        shootDealerGun = new JLabel(dealerGun);
        shootDealerGun.setBounds(380, 100, 301, 157);
        shootDealerGun.setVisible(false);

        ImageIcon dealerGunEmpty = new ImageIcon(getClass().getResource("/gun1C1_.png"));
        shootDealerGunEmpty = new JLabel(dealerGunEmpty);
        shootDealerGunEmpty.setBounds(380, 100, 301, 157);
        shootDealerGunEmpty.setVisible(false);


        ImageIcon playerGun = new ImageIcon(getClass().getResource("/gun0C2M_.png"));
        shootPlayerGun = new JLabel(playerGun);
        shootPlayerGun.setBounds(380, 100, 301, 157);
        shootPlayerGun.setVisible(false);

        ImageIcon playerGunEmpty = new ImageIcon(getClass().getResource("/gun1C1M_.png"));
        shootPlayerGunEmpty = new JLabel(playerGunEmpty);
        shootPlayerGunEmpty.setBounds(380, 100, 301, 157);
        shootPlayerGunEmpty.setVisible(false);


        ImageIcon dealerGun1 = new ImageIcon(getClass().getResource("/gun0C2M_.png"));
        shootDealerGun1 = new JLabel(dealerGun1);
        shootDealerGun1.setBounds(110, 100, 301, 157);
        shootDealerGun1.setVisible(false);

        ImageIcon dealerGunEmpty1 = new ImageIcon(getClass().getResource("/gun1C1_.png"));
        shootDealerGunEmpty1 = new JLabel(dealerGunEmpty1);
        shootDealerGunEmpty1.setBounds(110, 100, 301, 157);
        shootDealerGunEmpty1.setVisible(false);

        ImageIcon playerGun1 = new ImageIcon(getClass().getResource("/gun1C5_.png"));
        shootPlayerGun1 = new JLabel(playerGun1);
        shootPlayerGun1.setBounds(110, 100, 301, 157);
        shootPlayerGun1.setVisible(false);

        ImageIcon playerGunEmpty1 = new ImageIcon(getClass().getResource("/gun1C1_.png"));
        shootPlayerGunEmpty1 = new JLabel(playerGunEmpty1);
        shootPlayerGunEmpty1.setBounds(110, 100, 301, 157);
        shootPlayerGunEmpty1.setVisible(false);



        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Russian Roulette");
        frame.setSize(900, 600);
        frame.setResizable(false);
        frame.setVisible(true);
        frame.setLayout(null);
        frame.add(blkSc);
        frame.add(winSc);
        frame.add(lostSc);
        frame.add(prizePool);
        frame.add(dealerSafeStat);
        frame.add(shootYourselfButton);
        frame.add(shootDealerButton);
        frame.add(dealer);
        frame.add(dealerTxt);
        frame.add(player);
        frame.add(playerTxt);
        frame.add(shootDealerGun);
        frame.add(shootPlayerGun);
        frame.add(shootDealerGun1);
        frame.add(shootPlayerGun1);
        frame.add(shootDealerGunEmpty);
        frame.add(shootPlayerGunEmpty);
        frame.add(shootDealerGunEmpty1);
        frame.add(shootPlayerGunEmpty1);
        frame.add(restartBtn);
        frame.add(stat);




    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (!gameOver) { // Only proceed if the game is not over
            if (turn == 0) { // Player's turn
                System.out.println("Current pos : " + currentPosition);
                shootDealerGun1.setVisible(false);
                shootPlayerGun1.setVisible(false);
                shootDealerGunEmpty1.setVisible(false);
                shootPlayerGunEmpty1.setVisible(false);

                if (e.getSource() == shootDealerButton) {
                    if (currentPosition == bulletPosition) {
                        shootDealerGun.setVisible(true);
                        winSc.setText("You Won $" + prize);
                        winSc.setVisible(true);
                        gameOver = true;
                        disableButtons();
                        restartBtn.setVisible(true);
                    } else {
                        shootDealerGunEmpty.setVisible(true);
                        currentPosition = (currentPosition + 1) % 6; // Increment and wrap around
                        turn = 1; // Switch to dealer's turn

                        stat.setText("Dealer is safe");
                        stat.setVisible(true);
                        Timer timer0 = new Timer(1000, ae -> stat.setVisible(false));
                        timer0.setRepeats(false); // Ensure the timer only runs once
                        timer0.start(); // Delay for dealer's turn
                        disableButtons(); // Disable buttons during dealer's turn
                        Timer timer = new Timer(1000, ae -> dealerTurn());
                        timer.setRepeats(false); // Ensure the timer only runs once
                        timer.start(); // Delay for dealer's turn
                    }
                } else if (e.getSource() == shootYourselfButton) {
                    if (currentPosition == bulletPosition) {
                        shootPlayerGun.setVisible(true);
                        lostSc.setVisible(true);
                        gameOver = true;
                        disableButtons();
                        restartBtn.setVisible(true);
                    } else {
                        shootPlayerGunEmpty.setVisible(true);
                        currentPosition = (currentPosition + 1) % 6; // Increment and wrap around
                        turn = 1; // Switch to dealer's turn
                        prize += 5000;
                        prizePool.setText("Current Prize Pool : $" + prize);
                        stat.setText("You are safe. $5000 added to your prize pool.");
                        stat.setVisible(true);
                        Timer timer0 = new Timer(1000, ae -> stat.setVisible(false));
                        timer0.setRepeats(false); // Ensure the timer only runs once
                        timer0.start(); // Delay for dealer's turn
                        disableButtons(); // Disable buttons during dealer's turn
                        Timer timer = new Timer(1000, ae -> dealerTurn());
                        timer.setRepeats(false); // Ensure the timer only runs once
                        timer.start(); // Delay for dealer's turn
                    }
                }
            }
        }

        if(e.getSource() == restartBtn){
            frame.dispose();
            GameScreen gsc = new GameScreen();
        }
    }

    private void dealerTurn() {
        if (gameOver) return; // Exit if the game is already over

        System.out.println("Current pos : " + currentPosition);

        // Hide all gun images
        shootDealerGun.setVisible(false);
        shootPlayerGun.setVisible(false);
        shootDealerGunEmpty.setVisible(false);
        shootPlayerGunEmpty.setVisible(false);
        shootDealerGun1.setVisible(false);
        shootPlayerGun1.setVisible(false);
        shootDealerGunEmpty1.setVisible(false);
        shootPlayerGunEmpty1.setVisible(false);

        int dealerChoice = random.nextInt(2) + 1;

        if (dealerChoice == 1) {
            if (currentPosition == bulletPosition) {
                shootDealerGun1.setVisible(true);
                lostSc.setVisible(true);
                gameOver = true;
                disableButtons();
                restartBtn.setVisible(true);

            } else {
                shootDealerGunEmpty1.setVisible(true);
                currentPosition = (currentPosition + 1) % 6; // Increment and wrap around
                turn = 0;
                stat.setText("You are safe");
                stat.setVisible(true);
                Timer timer0 = new Timer(1000, ae -> stat.setVisible(false));
                timer0.setRepeats(false); // Ensure the timer only runs once
                timer0.start(); // Delay for dealer's turn
                Timer timer = new Timer(1000, ae -> enableButtons());
                timer.setRepeats(false); // Ensure the timer only runs once
                timer.start(); // Delay for dealer's turn
            }
        } else if (dealerChoice == 2) {
            if (currentPosition == bulletPosition) {
                shootPlayerGun1.setVisible(true);
                winSc.setText("You Won $" + prize);
                winSc.setVisible(true);
                gameOver = true;
                disableButtons();
                restartBtn.setVisible(true);
            } else {
                shootPlayerGunEmpty1.setVisible(true);
                currentPosition = (currentPosition + 1) % 6; // Increment and wrap around
                turn = 0;
                stat.setText("Dealer is safe");
                stat.setVisible(true);
                Timer timer0 = new Timer(1000, ae -> stat.setVisible(false));
                timer0.setRepeats(false); // Ensure the timer only runs once
                timer0.start(); // Delay for dealer's turn
                Timer timer = new Timer(1000, ae -> enableButtons());
                timer.setRepeats(false); // Ensure the timer only runs once
                timer.start(); // Delay for dealer's turn
            }
        }

        // Ensure the frame updates to reflect the visibility changes
        frame.repaint();
    }



    private void disableButtons() {
        shootYourselfButton.setVisible(false);
        shootDealerButton.setVisible(false);
    }

    private void enableButtons() {
        shootYourselfButton.setVisible(true);
        shootDealerButton.setVisible(true);
    }

}
