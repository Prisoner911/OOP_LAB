package exceptionHandeling;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Main
 */
public class Main {

    public static void main(String[] args){
        int Roll;
        String Name;
        float avg;
        int flag = 1;
        Scanner inp = new Scanner(System.in);

        while (flag == 1 ) {
            System.out.println("Enter the roll no. : ");
            try {
                 Roll = inp.nextInt();
                 flag = 0;
            } catch (InputMismatchException e) {
                System.out.println("Roll no. must strictly be an integer");
                inp.next(); // discard the invalid input
            }
          
        }
        
    }
}