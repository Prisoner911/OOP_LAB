package LambdaExpressions;

public interface Test {

    public int add(int a, int b);
    
}
