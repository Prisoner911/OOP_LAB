package LambdaExpressions;

public class Main {

    // @Override
    // public int add(int a, int b) {
    //     return a+b;
    // }

    public static void main(String[] args){

        Test operateTest = (a, b) -> a+b;
        System.out.println(operateTest.add(5, 5));
    }
}
