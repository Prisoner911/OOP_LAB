package Generics;

public class Generic<T> {
    public T ID;
    public T a;
    public T b;
    public void cat(T a, T b){
        System.out.println(a);
        System.out.println(b);
    }
    
 
}
