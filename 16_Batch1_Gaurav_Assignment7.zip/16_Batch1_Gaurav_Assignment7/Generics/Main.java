package Generics;

public class Main {
    public static void main(String[] args)
    {
        Generic<Integer> genInt = new Generic<>();
        
        genInt.ID = 10;
        genInt.a = 10;
        genInt.b = 20;
        genInt.cat(genInt.a, genInt.b);

        Generic<String> genStr = new Generic<>();
        
        genStr.ID = "ABC";
        genStr.a = "Hello";
        genStr.b = "World";
        genStr.cat(genStr.a, genStr.b);
    }
}
