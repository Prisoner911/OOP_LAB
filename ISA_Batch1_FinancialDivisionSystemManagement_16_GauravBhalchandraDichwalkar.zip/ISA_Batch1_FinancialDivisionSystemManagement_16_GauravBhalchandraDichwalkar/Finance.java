/**
 * This class represents a financial record, including details about 
 * the date of the expense, the budget amount, the expense amount, 
 * and the reason for the expense.
 */
public class Finance {
   public String date; // The date of the financial record
   public int budgetAmount; // The budget amount remaining after the expense
   public int expenseAmount; // The amount of the expense
   public String expenseReason; // The reason for the expense

   /**
    * Constructor to initialize a Finance object with specified values.
    * 
    * @param date The date of the expense.
    * @param budgetAmount The remaining budget amount after the expense.
    * @param expenseAmount The amount of the expense.
    * @param expenseReason The reason for the expense.
    */
   public Finance(String date, int budgetAmount, int expenseAmount, String expenseReason) {
       this.date = date;
       this.budgetAmount = budgetAmount;
       this.expenseAmount = expenseAmount;
       this.expenseReason = expenseReason;
   }
}
