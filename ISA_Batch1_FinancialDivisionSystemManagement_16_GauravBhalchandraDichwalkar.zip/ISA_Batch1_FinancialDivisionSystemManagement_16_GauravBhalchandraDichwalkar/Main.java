import java.util.Scanner;

/**
 * The Main class is the entry point for the Division Management 
 * application, allowing users to manage their budget and expenses.
 */
public class Main {

    /**
     * Default constructor for the Main class.
     */
    public Main() {
    }

    /**
     * The main method serves as the entry point for the application. 
     * It provides a menu-driven interface for users to set budgets, 
     * add expenses, and display all expenses.
     *
     * @param var0 Command-line arguments (not used).
     */
    public static void main(String[] var0) {
        DivisionManagement dm = new DivisionManagement();
        Scanner inp = new Scanner(System.in);
        
        while (true) {
            // Check if the budget is exceeded
            if (dm.budgetAmount < 0) {
                System.out.print("\n\n-- You are over budget! --");
                System.out.println();
                System.out.println("Current Remainig budget : " + dm.budgetAmount);
            }

            // Display menu options
            System.out.println("\n| Enter your choice |");
            System.out.println("-----------------------------------------------------------------------------------------------------------------------\n");
            System.out.println("o To set budget: 1\n");
            System.out.println("o To Add expense details: 2\n");
            System.out.println("o To display all the expenses: 3\n");
            System.out.println("o To exit: 0\n");
            System.out.print("> Choice : ");
         
            
            // Get user choice
            int choice = inp.nextInt();
          
            System.out.println();
            System.out.println("-----------------------------------------------------------------------------------------------------------------------\n");
            // Process user choice
            switch (choice) {
                case 1:
                    dm.setBudget(); // Set budget
                    break;
                case 2:
                    dm.setDetails(); // Add expense details
                    break;
                case 3:
                    dm.display(); // Display all expenses
                    break;
                case 0:
                    System.exit(0); // Exit application
                    break;
                default:
                    System.out.println("- Not a proper choice");
                    break;
            }
        }
    }
}
