import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * This class manages the division's financial operations including setting budgets,
 * recording expenses, and displaying financial details.
 */
public class DivisionManagement extends Finance {
    public int budgetAmount; // The total budget amount for the division
    public String date; // The date of the expense entry
    public int expenseAmount; // The amount of the expense
    public String expenseReason; // The reason for the expense
    public List<Finance> financeList = new ArrayList<>(); // List to store finance records
    public Scanner inp; // Scanner for user input

    /**
     * Constructor for the DivisionManagement class.
     * Initializes the scanner and the superclass constructor.
     */
    public DivisionManagement() {
        super(null, 0, 0, null);
        inp = new Scanner(System.in);
    }

    /**
     * Prompts the user to enter a budget amount and sets the budget.
     * It ensures that the input is a valid integer.
     */
    public void setBudget() {
        while (true) {
            System.out.println("Enter budget: ");
            try {
                budgetAmount = inp.nextInt();
                inp.nextLine(); // Clear the buffer after reading int
                System.out.println("Budget set to: " + budgetAmount);
                break; // Exit the loop on successful input
            } catch (Exception e) {
                System.out.println("Invalid input! Please enter a valid integer for the budget.");
                inp.nextLine(); // Clear the invalid input
            }
        }
        System.out.println();
        System.out.println("-----------------------------------------------------------------------------------------------------------------------\n");
    }

    /**
     * Prompts the user to enter the date, expense amount, and expense reason,
     * and then records these details in the finance list.
     * It ensures that the expense amount is a valid integer and deducts
     * the expense from the budget.
     */
    public void setDetails() {
        System.out.println("> Enter Date: ");
        date = inp.nextLine();

        while (true) {
            System.out.println("> Enter Expense: ");
            try {
                expenseAmount = inp.nextInt();
                inp.nextLine(); // Clear the buffer after reading int
                break; // Exit the loop on successful input
            } catch (Exception e) {
                System.out.println("- Invalid input! Please enter a valid integer for the expense.");
                inp.nextLine(); // Clear the invalid input
            }
        }

        System.out.println("> Enter Expense Reason: ");
        expenseReason = inp.nextLine();

        // Deduct the expense from the budget
        budgetAmount -= expenseAmount;

        // Create a new Finance object and add it to the list
        Finance finance = new Finance(date, budgetAmount, expenseAmount, expenseReason);
        financeList.add(finance);
        System.out.println();
        System.out.println("-----------------------------------------------------------------------------------------------------------------------\n");
    }

    /**
     * Displays all recorded finance entries, including the date, expense amount,
     * expense reason, and remaining budget for each entry.
     */
    public void display() {
        System.out.println("-----------------------------------------------------------------------------------------------------------------------");
        for (Finance finance : financeList) {
            System.out.println("- Date: " + finance.date);
            System.out.println("- Expense: " + finance.expenseAmount);
            System.out.println("- Expense Reason: " + finance.expenseReason);
            System.out.println("- Remaining budget: " + finance.budgetAmount);

            System.out.println("-----------------------------------------------------------------------------------------------------------------------");
        }
       
    }
}
