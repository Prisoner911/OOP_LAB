/*
 * Author : Gaurav B. Dichwalkar
 * Roll no. : 15
 * Title : Institute register
 * Description : This is a menu driven that takes institute name and its details as input and stores it inside a list.
 * Created at : 10/07/2024
 * Modified at : 24/07/2024
 */

package EducationalInstituesOfIndia;

import java.util.Scanner;

// This is a driver class. Here we get to make choice on what we want to do.
public class driver extends InstituteManagement {
    public static void main(String[] args) {
        int choice;
        boolean quit = false;

        do {
            InstituteManagement institute = new InstituteManagement();
            System.out.println("\n1. Add new institute");
            System.out.println("2. Remove an institute");
            System.out.println("3. Display all institutes");
            System.out.println("0. Quit");
            System.out.println();
            System.out.print("> Enter your choice: ");
            Scanner input = new Scanner(System.in);
            choice = input.nextInt();

            switch (choice) {
                case 1:
                    institute.addInstitute();
                    break;

                case 2:
                    institute.removeInstitute();
                    break;

                case 3:
                    institute.displayAll();
                    break;

                case 0:
                    quit = true;
                    break;

                default:
                    System.out.println("> Enter a valid input.");
                    break;
            }

        } while (quit == false);
    }
}
