﻿/*
 * Author : Gaurav B. Dichwalkar
 * Roll no. : 15
 * Title : Institute register
 * Description : This is a menu driven that takes institute name and its details as input and stores it inside a list.
 * Created at : 10/07/2024
 * Modified at : 24/07/2024
 */


using System;

namespace Educational_Institutes
{
    // This is a class which is used to create a custom datatype.
    public class Institutes
    {
        public int sno;
        public string instituteName;
        public string city;
        public string stUt;
        public string nameOfAct;
        public string adminDpt;

        public Institutes(int sno, string instituteName, string city, string stUt, string nameOfAct,
            string adminDpt)
        {
            this.sno = sno;
            this.instituteName = instituteName;
            this.city = city;
            this.stUt = stUt;
            this.nameOfAct = nameOfAct;
            this.adminDpt = adminDpt;
        }

    }
    // This class manages the input and other functions.
    public class StdList : Institutes
    {
        public StdList() : base(0, "", "", "", "", "") { }
        public List<Institutes> InstitutesList = new List<Institutes>();

        public void addIst()
        {
            int sno;
            while (true)
            {
                try
                {
                    Console.Write("> Enter the serial no.: ");
                    sno = Convert.ToInt32(Console.ReadLine());
                    break;  // Break out of the loop if conversion is successful
                }
                catch
                {
                    Console.WriteLine("> Serial no. can only be an integer\n");
                }
            }

            Console.Write("> Enter the name of an institute: ");
            string instituteName = Console.ReadLine();

            Console.Write("> Enter the name of the city: ");
            string city = Console.ReadLine();

            Console.Write("> Enter the name of the state/union territory: ");
            string stUt = Console.ReadLine();

            Console.Write("> Enter the name of act: ");
            string nameOfAct = Console.ReadLine();

            Console.Write("> Enter the administration department: ");
            string adminDept = Console.ReadLine();

            Institutes institute = new Institutes(sno, instituteName, city, stUt, nameOfAct, adminDept);

            InstitutesList.Add(institute);
        }


        public void removeIst()
        {
            if (InstitutesList.Count < 1)
            {
                Console.WriteLine();
                Console.WriteLine(">> No Institutes found in the list");
            }
            else
            {
                Console.WriteLine();
                Console.Write("Enter the serial no. of the institute you want to delete : ");
                int toRemoveSerial = Convert.ToInt32(Console.ReadLine());
                bool found = false;
                string toRemoveinstituteName = "";

                foreach (Institutes institute in InstitutesList)
                {
                    if (institute.sno == toRemoveSerial)
                    {
                        toRemoveinstituteName = institute.instituteName;
                        InstitutesList.Remove(institute);
                        found = true;
                        break;
                    }
                    else
                    {
                        found = false;
                    }
                }

                if (found == false)
                {
                    Console.WriteLine();
                    Console.WriteLine(">> No such student found.");
                }

                else
                {
                    Console.WriteLine();
                    Console.WriteLine(toRemoveinstituteName + " was removed.");
                }
            }
        }

        public void displayIst()
        {
            if (InstitutesList.Count < 1)
            {
                Console.WriteLine();
                Console.WriteLine(">> No Institutes found in the list");
            }
            else
            {
                foreach (Institutes student in InstitutesList)
                {
                    Console.WriteLine();
                    Console.WriteLine(">> Serial No. : " + student.sno);
                    Console.WriteLine(">> Institute Name : " + student.instituteName);
                    Console.WriteLine(">> Institute Name : " + student.city);
                    Console.WriteLine(">> Institute Name : " + student.stUt);
                    Console.WriteLine(">> Institute Name : " + student.nameOfAct);
                    Console.WriteLine(">> Institute Name : " + student.adminDpt);

                }
            }
        }

    }

    // This is a driver class. Here we get to make choice on what we want to do.
    public class hw
    {
        static void Main(string[] args)
        {
            int input;
            StdList data = new StdList();
            bool status = false;
            do
            {


                Console.WriteLine();
                Console.WriteLine("To add student - 1");
                Console.WriteLine("To remove student - 2");
                Console.WriteLine("To display the list of the Institutes - 3");
                Console.WriteLine("To clear screen  - 4");
                Console.WriteLine("To exit - 0");
                Console.Write("> ");
                input = Convert.ToInt32(Console.ReadLine());



                switch (input)
                {

                    case 1:
                        data.addIst();
                        break;

                    case 2:
                        data.removeIst();
                        break;

                    case 3:
                        data.displayIst();
                        break;

                    case 4:
                        Console.Clear();
                        break;

                    case 0:
                        status = true;
                        break;

                    default:
                        Console.WriteLine();
                        Console.WriteLine(">> Enter a valid input.");
                        break;


                }
            }
            while (status == false);

        }
    }
}
