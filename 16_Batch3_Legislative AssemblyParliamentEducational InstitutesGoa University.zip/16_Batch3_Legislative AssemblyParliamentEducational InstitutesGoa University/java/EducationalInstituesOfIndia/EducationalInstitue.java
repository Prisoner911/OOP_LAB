/*
 * Author : Gaurav B. Dichwalkar
 * Roll no. : 15
 * Title : Institute register
 * Description : This is a menu driven that takes institute name and its details as input and stores it inside a list.
 * Created at : 10/07/2024
 * Modified at : 24/07/2024
 */

package EducationalInstituesOfIndia;

// This is a class which is used to create a custom datatype.
public class EducationalInstitue {
    public int sno;
    public String instituteName;
    public String city;
    public String stUt;
    public String nameOfAct;
    public String adminDpt;

    public EducationalInstitue(int sno, String instituteName, String city, String stUt, String nameOfAct,
            String adminDpt) {
        this.sno = sno;
        this.instituteName = instituteName;
        this.city = city;
        this.stUt = stUt;
        this.nameOfAct = nameOfAct;
        this.adminDpt = adminDpt;
    }

}
