/*
 * Author : Gaurav B. Dichwalkar
 * Roll no. : 15
 * Title : Institute register
 * Description : This is a menu driven that takes institute name and its details as input and stores it inside a list.
 * Created at : 10/07/2024
 * Modified at : 24/07/2024
 */


package EducationalInstituesOfIndia;

import java.util.*;

// This class manages the input and other functions.
public class InstituteManagement extends EducationalInstitue {
   public static List<EducationalInstitue> myInstitues = new ArrayList<>();

   public InstituteManagement(){
        super(0, "", "", "", "", "");
   }

   public void addInstitute(){
    Scanner input = new Scanner(System.in);
    System.out.println("Enter the Institute details:");
    System.out.print("Institute name: ");
    String instituteName = input.nextLine();
    System.out.print("City: ");
    String city = input.nextLine();
    System.out.print("State/UT: ");
    String state = input.nextLine();
    System.out.print("Name of Act: ");
    String nameOfAct = input.nextLine();
    System.out.print("Administration Department: ");
    String adminDpt = input.nextLine();

    int sno = myInstitues.size() + 1;
    

    EducationalInstitue edu = new EducationalInstitue(sno, instituteName, city, state, nameOfAct, adminDpt);
    myInstitues.add(edu);

   
        
   }

   public void removeInstitute(){
    Scanner input = new Scanner(System.in);

    if(myInstitues.isEmpty()){
        System.out.println();
        System.out.println("> List is empty");
        
    }
    else{
       
        System.out.println("Enter the Serial Number of the Institute to remove : ");
        int Sno = input.nextInt();
        boolean removed = false;
        String nameInst = null;
        for (EducationalInstitue institute : myInstitues){
            if(institute.sno == Sno){
                nameInst = institute.instituteName;
                break;
            }
        }
        removed = myInstitues.removeIf(institute -> institute.sno == Sno);
      
        if (removed) {
            System.out.println();
            System.out.println("> "+ nameInst +" was removed.");
        }
        else{
            System.out.println();
            System.out.println("> Institute not found.");
        }
    }



   
   }

   public void displayAll(){
    if (myInstitues.isEmpty()) {
        System.out.println("List is empty");
    } else {
        for(EducationalInstitue obj : myInstitues){
            System.out.println();
            System.out.println("> Sno : " + obj.sno);
            System.out.println("> Institute Name : " + obj.instituteName);
            System.out.println("> City : " + obj.city);
            System.out.println("> State/UT : " + obj.stUt);
            System.out.println("> Name of Act : " + obj.nameOfAct);
            System.out.println("> Administration Department : " + obj.adminDpt);
            System.out.println("----------------------------------------------------------------------------");
        }
    }
   }
}
