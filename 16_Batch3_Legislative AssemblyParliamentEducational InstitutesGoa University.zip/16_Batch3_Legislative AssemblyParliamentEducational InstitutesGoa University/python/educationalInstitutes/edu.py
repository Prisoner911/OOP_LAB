
#   Author : Gaurav B. Dichwalkar
#   Roll no. : 15
#   Title : Institute register
#   Description : This is a menu driven that takes institute name and its details as input and stores it inside a list.
#   Created at : 10/07/2024
#   Modified at : 24/07/2024
 



# this class takes the input and acts as a custom datatype and stores it in a list.
class institute:
    details = []
    
    def addIst(self):
        while True:
            try:
                sno = int(input("Enter the serial no.: "))
                break
            except:
                print("> Serial number can only be an integer value\n")
        
        instituteName = str(input("Enter institute name : "))
        city = str(input("Enter the city : "))
        stUt = str(input("Enter the state/union territory : "))
        nameofAct = str(input("Enter the Name of Act : "))
        adminDept = str(input("Enter the administration department : "))
        
        instDetails = {"S_No" : sno,  "Institute_Name" : instituteName, "City" : city, "St_Ut" : stUt, "Name_of_Act" : nameofAct, "Admin_Deptartment" : adminDept}
 
        
        institute.details.append(instDetails)
        print()
    
    def removeIst(self):
        removalStat = False
        toRemove = int(input("Enter the serial no. of the institute to be removed : "))
        for data in institute.details:
            if data['sno'] == toRemove:
                toRemoveName = data['instituteName']
                institute.details.remove(data)
                removalStat = True
                break
        if removalStat == True:
            print(f">> {toRemoveName} was removed.")
            print()
        else:
            print(f">> {toRemoveName} not found.")
            print()
            
    def display(self):
        print()
        print(">> Institute Details : ")
        print()
        if not institute.details:
            print(">> List is empty")
            print()
        else:
            for data in institute.details:
                for key, value in data.items():
                    print(f"{key}: {value}")
                print()


# This class is a driver class that allows user to choose operations.
class hw(institute):
    runStatus = True
    
    while(runStatus == True):
        print("To add an institute - 1")
        print("To remove an institute - 2")
        print("To display list - 3")
        print("To exit - 0")
        inp = int(input("> "))
        obj = institute()
        if inp == 1:
            obj.addIst()
            
        elif inp == 2:
            obj.removeIst()
        
        elif inp == 3:
            obj.display()
        
        elif inp == 0:
            runStatus = False
        
        else:
            print("Enter a valid input")
        
        
            
    
