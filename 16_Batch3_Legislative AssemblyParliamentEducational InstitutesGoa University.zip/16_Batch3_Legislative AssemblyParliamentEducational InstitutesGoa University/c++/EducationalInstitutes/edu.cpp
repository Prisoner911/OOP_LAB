/*
 * Author : Gaurav B. Dichwalkar
 * Roll no. : 15
 * Title : Institute register
 * Description : This is a menu driven that takes institute name and its details as input and stores it inside a list.
 * Created at : 10/07/2024
 * Modified at : 24/07/2024
 */


#include <iostream>
#include <list>
#include <string>
using namespace std;


// This is a struct which is used to create a custom datatype.
struct EducationalInstitute
{
    int sno;
    string instituteName;
    string city;
    string stUt;
    string nameofAct;
    string adminDept;

    friend ostream &operator<<(ostream &os, const EducationalInstitute &details)
    {
        os << endl
           << ">> S.No : " << details.sno << endl
           << ">> Institute Name : " << details.instituteName << endl
           << ">> City : " << details.city << endl
           << ">> State/Union Territory : " << details.stUt << endl
           << ">> Name of Act : " << details.nameofAct << endl
           << ">> Administration/Department : " << details.adminDept << endl;
        return os;
    }
};

// This is a class that takes input.
class InstituteManagement
{
public:
    list<EducationalInstitute> details;

    void addInstitute()
    {
        EducationalInstitute institute;
         if(details.empty()){
            institute.sno = 1;
        }
        else{
           institute.sno = details.back().sno + 1;
        }
        cin.ignore();

        cout << "Enter the Institute Name: ";
        getline(cin, institute.instituteName);

        cout << "Enter the City: ";
        getline(cin, institute.city);

        cout << "Enter the State/Union Territory: ";
        getline(cin, institute.stUt);

        cout << "Enter the Name of Act: ";
        getline(cin, institute.nameofAct);

        cout << "Enter the Administration/Department: ";
        getline(cin, institute.adminDept);

        details.push_back(institute);
        system("cls");
    }

    void removeInstitute()
    {
        int toRemove;
        bool instituteFound = false;
        cout << "Enter the Serial No. of the institute to be removed: ";
        cin >> toRemove;

        details.remove_if([toRemove, &instituteFound](const EducationalInstitute &institute)
                          {
                              if (toRemove == institute.sno)
                              {
                                  cout << ">> " << institute.instituteName << " was removed." << endl;
                                  instituteFound = true;
                                  return true;
                              }
                              return false; });

        if (!instituteFound)
        {
            cout << endl
                 << ">> No such institute found." << endl;
        }
    }

    void getDetails()
    {
        if (details.empty())
        {
            cout << ">> List is empty." << endl
                 << endl;
        }
        else
        {
            for (const auto &data : details)
            {
                cout << "*********************************************************" << endl;
                cout << data;
                cout << "*********************************************************" << endl;
            }
        }
    }
};

int main()
{
    InstituteManagement std;
    bool status = true;

    do
    {

        char input;
        cout << endl
             << "To add institute - 1" << endl;
        cout << "To remove institute - 2" << endl;
        cout << "To display list - 3" << endl;
        cout << "To clear the screen - 4" << endl;
        cout << "To Exit - 0" << endl;
        cout << "> ";
        cin >> input;

        switch (input)
        {
        case '1':
            std.addInstitute();
            break;

        case '2':
            std.removeInstitute();
            break;

        case '3':
            std.getDetails();
            break;

        case '4':
            system("cls");
            break;

        case '0':
            status = false;
            break;

        default:
            cout << ">> Enter a valid input." << endl
                 << endl;
            break;
        }
    } while (status == true);

    return 0;
}
