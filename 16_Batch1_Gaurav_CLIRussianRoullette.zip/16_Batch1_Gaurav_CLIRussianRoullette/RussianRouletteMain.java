package russianRoulette;

import java.util.*;

public class RussianRouletteMain {
	public void sleepfunc(int x) {
		  try {
				Thread.sleep(x);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
	}
	 public static void main(String[] args) {
		 	int prize = 50000;

	        Scanner scanner = new Scanner(System.in);
	        RussianRouletteMain rr = new RussianRouletteMain();
	        Random random = new Random();
	        
	        int bulletPosition = random.nextInt(6) + 1; // Randomly placing the bullet in one chamber
	        int currentPosition = random.nextInt(6) + 1; // Starting position of the revolver
	        boolean gameOver = false;

	        System.out.println("Welcome to Russian Roulette!");
			rr.sleepfunc(1000);
			System.out.println();
			System.out.println("Prize pool of $" + prize);
	        rr.sleepfunc(1000);
			System.out.println();
	        System.out.println("The revolver has 6 chambers, and one of them has a bullet.");
			rr.sleepfunc(1000);
			System.out.println();
			System.out.println("Every time you shoot at yourself and if you are safe, $5000 will be added to your prize pool.");
	        
	        while (!gameOver) {
	            // Player's turn
	        	rr.sleepfunc(1000);
	            System.out.println("\nIt's your turn. Choose:");
	            System.out.println("1. Shoot yourself");
	            System.out.println("2. Shoot the dealer");
	            System.out.print(">  ");
	            int choice = scanner.nextInt();

	            if (choice == 1) {
					System.out.println();
	                System.out.println("You chose to shoot yourself...");
	                if (currentPosition == bulletPosition) {
	                	rr.sleepfunc(500);
						System.out.println();
	                    System.out.println("Bang! You are dead. The bullet was in chamber " + bulletPosition + ".");
	                    gameOver = true;
	                } else {
	                	rr.sleepfunc(500);
						System.out.println();
	                    System.out.println("Click! You're safe.");
						rr.sleepfunc(500);
						System.out.println();
						prize = prize + 5000;
						System.out.println("Current prize pool $" + prize);
	                    currentPosition++;
	                }
	            } else if (choice == 2) {
					System.out.println();
	                System.out.println("You chose to shoot the dealer...");
	                if (currentPosition == bulletPosition) {
	                	rr.sleepfunc(500);
						System.out.println();
	                    System.out.println("Bang! The dealer is dead. The bullet was in chamber " + bulletPosition + ".");
						rr.sleepfunc(500);
						System.out.println();
						System.out.println("You won $" + prize);
						rr.sleepfunc(500);
	                    gameOver = true;
	                } else {
	                	rr.sleepfunc(500);
						System.out.println();
	                    System.out.println("Click! The dealer is safe.");
	                    currentPosition++;
	                }
	            } else {
					System.out.println();
	                System.out.println("Invalid choice. Try again.");
	                continue;
	            }

	            if (gameOver) break;

	            // Dealer's turn (Computer)
	            rr.sleepfunc(1000);
				System.out.println();
	            System.out.println("\nIt's the dealer's turn...");
	            int dealerChoice = random.nextInt(2) + 1;

	            if (dealerChoice == 1) {
	            	rr.sleepfunc(500);
					System.out.println();
	                System.out.println("The dealer chose to shoot himself...");
	                if (currentPosition == bulletPosition) {
	                	rr.sleepfunc(300);
						System.out.println();
	                    System.out.println("Bang! The dealer is dead. The bullet was in chamber " + bulletPosition + ".");
	                    gameOver = true;
	                } else {
	                	rr.sleepfunc(300);
						System.out.println();
	                    System.out.println("Click! The dealer is safe.");
	                    currentPosition++;
	                }
	            } else {
	            	rr.sleepfunc(500);
					System.out.println();
	                System.out.println("The dealer chose to shoot you...");
	                if (currentPosition == bulletPosition) {
	                	rr.sleepfunc(300);
						System.out.println();
	                    System.out.println("Bang! You are dead. The bullet was in chamber " + bulletPosition + ".");
	                    gameOver = true;
	                } else {
	                	rr.sleepfunc(300);
						System.out.println();
	                    System.out.println("Click! You are safe.");
	                    currentPosition++;
	                }
	            }
	        }

	        System.out.println("Game over.");
	        scanner.close();

	    }

}
