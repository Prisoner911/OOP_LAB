import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.awt.geom.Rectangle2D;
import java.util.concurrent.ThreadLocalRandom;

public class GamePanel extends JPanel implements ActionListener {
    private static final int WIDTH = 900;
    private static final int HEIGHT = 600;
    private static final int TIMER_DELAY = 20;

    private int obstacleSpawnCounter = 0; // Counter for obstacle spawning
    private int obstacleSpawnInterval = getRandomSpawnInterval(); // Random spawn interval

    // Method to get a random spawn interval between 18 and 30
    private int getRandomSpawnInterval() {
        return ThreadLocalRandom.current().nextInt(18, 30); 
    }


    private int groundLevel = HEIGHT - 250; // Define the ground level more clearly

    private BufferedImage background;
    private BufferedImage human;
    private BufferedImage trashCan;
    private final int initialHumanY = groundLevel;
    private int humanY = groundLevel; // Starting height of the human
    private int humanX = 50;
    private boolean jumping = false;
    private int jumpCount = 0;
    

    private ArrayList<Rectangle2D> obstacles; // Use Rectangle2D
    private Random random;
    private int score = 0;

    // Custom dimensions for human and trash can
    private final int humanWidth = 110;
    private final int humanHeight = 200;
    private final int trashCanWidth = 80;
    private final int trashCanHeight = 110;

    private ScrollingBackground scrollingBackground;

    public GamePanel() {
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setBackground(Color.WHITE);
        setFocusable(true); 
        requestFocusInWindow(); // Ensure the game panel can receive key events
    
        scrollingBackground = new ScrollingBackground("night_city.jpg", WIDTH, HEIGHT, 5);
    
        // Load images
        try {
            background = ImageIO.read(new File("night_city.jpg")); // Replace with your background image
            human = ImageIO.read(new File("manRunning.png")); // Replace with your human image
            trashCan = ImageIO.read(new File("trash.png")); // Replace with your trash can image
        } catch (IOException e) {
            e.printStackTrace();
        }
    
        obstacles = new ArrayList<>();
        random = new Random();
    
        // Key listener for jump action
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_SPACE && !jumping) {
                    jumping = true;
                }
            }
        });
    
        Timer timer = new Timer(TIMER_DELAY, this);
        timer.start();
    }
    

    private boolean gameStarted = false; // Track if the game has started

    public void startGame() {
        gameStarted = true; // Set the game started flag
        obstacles.clear(); // Clear any existing obstacles
        score = 0; // Reset the score
        humanY = initialHumanY; // Reset the human position
        jumpCount = 0; // Reset jump counter
        jumping = false; // Reset jumping state
    
        requestFocusInWindow(); // Ensure the game panel has focus for key events
        repaint(); // Repaint to show the game state
}

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

         // Draw the scrolling background
         scrollingBackground.draw(g);

         if (!gameStarted) {
            return; // Don't draw game elements if the game hasn't started
        }

        g.drawImage(background, 0, 0, WIDTH, HEIGHT, null);
        g.drawImage(human, humanX, humanY, humanWidth, humanHeight, null);

        // Draw obstacles (trash cans)
        for (Rectangle2D obstacle : obstacles) {
            g.drawImage(trashCan, (int) obstacle.getX(), (int) obstacle.getY(), trashCanWidth, trashCanHeight, null);
        }

        // Display score
        g.setColor(Color.BLACK);
        g.drawString("Score: " + score, 10, 20);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (!gameStarted) {
            return; // Don't update game state if the game hasn't started
        }

        // Update the scrolling background
        scrollingBackground.update();

        obstacleSpawnCounter++;

        if (jumping) {
            if (jumpCount < 10) {
                humanY -= 30; // Increase jump height
            } else if (jumpCount < 20) {
                humanY += 25; // Increase falling speed
            } else {
                // Reset jump
                jumping = false; // End jump
                jumpCount = 0;

                // Instead of resetting to groundLevel, return to initial position
                humanY = initialHumanY;
            }
            jumpCount++;
        } else {
            // Ensure the human character stays on the ground if not jumping
            if (humanY < initialHumanY) {
                humanY += 15; // Bring the character back to the original height gradually
            }
        }

        // Move obstacles (trash cans)
        for (int i = 0; i < obstacles.size(); i++) {
            Rectangle2D obstacle = obstacles.get(i);
            obstacle.setRect(obstacle.getX() - 15, obstacle.getY(), obstacle.getWidth(), obstacle.getHeight()); // Move left
            if (obstacle.getX() + obstacle.getWidth() < 0) {
                obstacles.remove(i);
                score++;
            }
        }

        // Generate obstacles (trash cans) at a fixed height
        if (obstacleSpawnCounter >= obstacleSpawnInterval) { // 1.3 seconds
            obstacles.add(new Rectangle2D.Double(WIDTH, 510 - trashCanHeight + 10, trashCanWidth, trashCanHeight)); // Use fixed height
            obstacleSpawnCounter = 0; // Reset the counter after spawning an obstacle
            obstacleSpawnInterval = getRandomSpawnInterval();
        }

        // Check for pixel-perfect collisions
        for (Rectangle2D obstacle : obstacles) {
            if (isColliding(humanX, humanY, humanWidth, humanHeight, obstacle.getX(), obstacle.getY(), trashCanWidth, trashCanHeight)) {
                // Trigger game over even if human is falling
                JOptionPane.showMessageDialog(this, "Game Over! Your Score: " + score);
                obstacles.clear();
                score = 0;
                humanY = initialHumanY;
                break;
            }
        }

        repaint();
    }

    // Method to check for pixel-perfect collision
    private boolean isColliding(int x1, int y1, int width1, int height1, double x2, double y2, int width2, int height2) {
        // Create rectangles for the human and the obstacle
        Rectangle2D humanBounds = new Rectangle2D.Double(x1, y1, width1, height1);
        Rectangle2D obstacleBounds = new Rectangle2D.Double(x2, y2, width2, height2);

        // Get intersection rectangle
        Rectangle2D intersection = humanBounds.createIntersection(obstacleBounds);

        if (intersection.isEmpty()) {
            return false; // No collision if intersection is empty
        }

        // Check pixels in the intersection area
        for (int y = (int) intersection.getY(); y < intersection.getY() + intersection.getHeight(); y++) {
            for (int x = (int) intersection.getX(); x < intersection.getX() + intersection.getWidth(); x++) {
                // Get pixel coordinates relative to images
                int pixelX1 = x - x1;
                int pixelY1 = y - y1;
                int pixelX2 = x - (int) x2;
                int pixelY2 = y - (int) y2;

                // Check if the pixels are not transparent
                if (isPixelOpaque(human, pixelX1, pixelY1) && isPixelOpaque(trashCan, pixelX2, pixelY2)) {
                    return true; // Collision detected
                }
            }
        }

        return false; // No collision detected
    }

    // Method to check if a pixel is opaque
    private boolean isPixelOpaque(BufferedImage image, int x, int y) {
        if (x < 0 || x >= image.getWidth() || y < 0 || y >= image.getHeight()) {
            return false; // Out of bounds
        }
        int pixel = image.getRGB(x, y);
        int alpha = (pixel >> 24) & 0xff; // Get alpha value
        return alpha != 0; // Return true if pixel is not transparent
    }
}
