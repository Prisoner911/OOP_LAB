import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

public class Human {
    public int x, y, width, height;
    private BufferedImage image;
    private boolean jumping = false;
    private int jumpSpeed = 0;
    private static final int GRAVITY = 1;
    private static final int JUMP_HEIGHT = 150; // Maximum height of jump
    private int groundLevel; // The ground level based on panel height

    public Human(int x, int y, int width, int height) {
        this.x = x;
        this.height = height;
        this.width = width;

        // Load human image
        loadImage("manRunning.png");

        // Set the initial position to be at the bottom
        this.groundLevel = 1080 - height; // Full HD bottom position
        this.y = groundLevel; // Start at ground level
    }

    private void loadImage(String imagePath) {
        try {
            image = ImageIO.read(new File(imagePath));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void move() {
        if (jumping) {
            // Move up
            y -= jumpSpeed;
            jumpSpeed -= GRAVITY; // Apply gravity

            // Check if the character has landed
            if (y >= groundLevel) { // If at the ground level
                y = groundLevel; // Reset to ground
                jumping = false; // Stop jumping
                jumpSpeed = 0; // Reset jump speed
            }
            // Prevent going above the panel
            if (y < groundLevel - JUMP_HEIGHT) {
                y = groundLevel - JUMP_HEIGHT; // Prevent going above jump height
            }
        }
    }

    public void jump() {
        if (!jumping) {
            jumping = true; // Start jumping
            jumpSpeed = JUMP_HEIGHT; // Set jump speed to maximum height
        }
    }

    public void draw(Graphics g) {
        if (image != null) {
            g.drawImage(image, x, y - height, null); // Draw the image above the ground level
        } else {
            g.setColor(Color.BLUE); // Fallback: draw a blue rectangle
            g.fillRect(x, y - height, width, height);
        }
    }
}
