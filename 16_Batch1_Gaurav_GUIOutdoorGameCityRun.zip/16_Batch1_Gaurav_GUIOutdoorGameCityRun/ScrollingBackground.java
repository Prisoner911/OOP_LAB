import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

public class ScrollingBackground {
    private BufferedImage background;
    private int x1, x2;
    private int speed;

    public ScrollingBackground(String imagePath, int width, int height, int speed) {
        try {
            background = ImageIO.read(new File(imagePath));
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Start with two images to create a seamless effect
        x1 = 0;
        x2 = width;
        this.speed = speed;
    }

    public void update() {
        x1 -= speed;
        x2 -= speed;

        // Reset the position to create an endless scrolling effect
        if (x1 < -background.getWidth()) {
            x1 = x2 + background.getWidth();
        }
        if (x2 < -background.getWidth()) {
            x2 = x1 + background.getWidth();
        }
    }

    public void draw(Graphics g) {
        // Draw the background images
        g.drawImage(background, x1, 0, null);
        g.drawImage(background, x2, 0, null);
    }
}
