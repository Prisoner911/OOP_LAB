import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TitleScreen extends JPanel {
    private JButton startButton;

    public TitleScreen(CardLayout cardLayout, JPanel parentPanel) {
        setLayout(new BorderLayout());
        JLabel titleLabel = new JLabel("Welcome to the City Run!", SwingConstants.CENTER);
        // JLabel titleHelp = new JLabel("Press Space to JUMP in the game", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 32));
        add(titleLabel, BorderLayout.CENTER);
        // add(titleHelp, BorderLayout.CENTER);

        startButton = new JButton("Start Game");
        startButton.setFont(new Font("Arial", Font.PLAIN, 24));
        startButton.addActionListener(new StartButtonListener(cardLayout, parentPanel));
        add(startButton, BorderLayout.SOUTH);
    }

    private class StartButtonListener implements ActionListener {
        private CardLayout cardLayout;
        private JPanel parentPanel;

        public StartButtonListener(CardLayout cardLayout, JPanel parentPanel) {
            this.cardLayout = cardLayout;
            this.parentPanel = parentPanel;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            cardLayout.show(parentPanel, "GamePanel"); // Switch to GamePanel
            ((GamePanel) parentPanel.getComponent(1)).startGame(); // Call method to start the game
        }
    }
}
