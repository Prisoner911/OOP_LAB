import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Game Title");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel mainPanel = new JPanel(new CardLayout());

        GamePanel gamePanel = new GamePanel();
        TitleScreen titleScreen = new TitleScreen((CardLayout) mainPanel.getLayout(), mainPanel);

        mainPanel.add(titleScreen, "TitleScreen");
        mainPanel.add(gamePanel, "GamePanel");

        frame.add(mainPanel);
        frame.setSize(900, 600);
        frame.setResizable(false);
        frame.setVisible(true);
    }
}
