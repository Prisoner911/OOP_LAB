package EducationalInstitutesOfIndia;

import EducationalInstitutesOfIndia.StateUT;
import EducationalInstitutesOfIndia.InstituteType;

public class Driver {
    public static void main(String[] args) {
        // Basic Institute
        EducationalInstitute institute1 = new EducationalInstitute(1, "ABC University", "Mumbai", StateUT.MAHARASHTRA, "UGC", "HRD", InstituteType.UNIVERSITY);
        institute1.showInstituteDetails();

        // Technical Institute (Multilevel inheritance)
        TechnicalInstitute techInstitute = new TechnicalInstitute(2, "Tech Institute", "Bangalore", StateUT.KARNATAKA, "AICTE", "Science & Tech Dept", InstituteType.INSTITUTE, "Computer Science");
        techInstitute.showInstituteDetails();

        // Medical Institute (Hierarchical inheritance)
        MedicalInstitute medInstitute = new MedicalInstitute(3, "XYZ Medical College", "Delhi", StateUT.DELHI, "MCI", "Health Dept", InstituteType.COLLEGE, 12);
        medInstitute.showInstituteDetails();

        // Hybrid Institute with interface
        HybridInstitute hybridInstitute = new HybridInstitute(4, "Online Tech College", "Pune", StateUT.MAHARASHTRA, "UGC", "Education Dept", InstituteType.COLLEGE, true);
        hybridInstitute.offerOnlineCourses();
    }
}
