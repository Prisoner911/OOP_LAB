package EducationalInstitutesOfIndia;

// Abstract class for defining basic institute functionality
public abstract class AbstractInstitute {
    protected int sno;
    private String instituteName;

    public AbstractInstitute(int sno, String instituteName) {
        this.sno = sno;
        this.instituteName = instituteName;
    }

    // Abstract (virtual) method to be implemented by subclasses
    public abstract void showInstituteDetails();

    // Getter for institute name
    public String getInstituteName() {
        return instituteName;
    }
}
