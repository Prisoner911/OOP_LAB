package EducationalInstitutesOfIndia;

// Enum for institute types
public enum InstituteType {
    UNIVERSITY,
    COLLEGE,
    SCHOOL,
    INSTITUTE
}
