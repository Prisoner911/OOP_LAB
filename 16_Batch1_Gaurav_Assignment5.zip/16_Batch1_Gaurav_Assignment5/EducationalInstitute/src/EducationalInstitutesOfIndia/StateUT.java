package EducationalInstitutesOfIndia;

// Enum for states and union territories
public enum StateUT {
    MAHARASHTRA,
    KARNATAKA,
    DELHI,
    TAMIL_NADU,
    WEST_BENGAL,
    OTHER
}
