package EducationalInstitutesOfIndia;

public interface OnlineEducation {
    void offerOnlineCourses();
}
