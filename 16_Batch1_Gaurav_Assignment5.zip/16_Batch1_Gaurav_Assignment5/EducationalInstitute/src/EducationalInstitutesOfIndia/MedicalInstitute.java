package EducationalInstitutesOfIndia;

// Another specialized class using hierarchical inheritance
public class MedicalInstitute extends EducationalInstitute {
    private int numOfDepartments;

    public MedicalInstitute(int sno, String instituteName, String city, StateUT stUt, String nameOfAct, String adminDpt, InstituteType instituteType, int numOfDepartments) {
        super(sno, instituteName, city, stUt, nameOfAct, adminDpt, instituteType);
        this.numOfDepartments = numOfDepartments;
    }

    @Override
    public void showInstituteDetails() {
        super.showInstituteDetails();
        System.out.println("Number of Departments: " + numOfDepartments);
    }
}
