package EducationalInstitutesOfIndia;

import EducationalInstitutesOfIndia.StateUT;
import EducationalInstitutesOfIndia.InstituteType;

// Multilevel inheritance example
public class TechnicalInstitute extends EducationalInstitute {
    private String specializedField;

    public TechnicalInstitute(int sno, String instituteName, String city, StateUT stUt, String nameOfAct, String adminDpt, InstituteType instituteType, String specializedField) {
        super(sno, instituteName, city, stUt, nameOfAct, adminDpt, instituteType);
        this.specializedField = specializedField;
    }

    @Override
    public void showInstituteDetails() {
        super.showInstituteDetails();
        System.out.println("Specialized Field: " + specializedField);
    }
}
