package EducationalInstitutesOfIndia;

// Hybrid inheritance: Extends class and implements interface
public class HybridInstitute extends EducationalInstitute implements OnlineEducation {
    private boolean onlineCourseAvailable;

    public HybridInstitute(int sno, String instituteName, String city, StateUT stUt, String nameOfAct, String adminDpt, InstituteType instituteType, boolean onlineCourseAvailable) {
        super(sno, instituteName, city, stUt, nameOfAct, adminDpt, instituteType);
        this.onlineCourseAvailable = onlineCourseAvailable;
    }

    @Override
    public void offerOnlineCourses() {
        System.out.println(getInstituteName() + " offers online courses: " + (onlineCourseAvailable ? "Yes" : "No"));
    }
}
