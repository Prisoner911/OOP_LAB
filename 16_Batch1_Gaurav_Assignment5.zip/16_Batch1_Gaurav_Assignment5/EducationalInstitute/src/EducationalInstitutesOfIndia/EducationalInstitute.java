package EducationalInstitutesOfIndia;

import EducationalInstitutesOfIndia.StateUT;
import EducationalInstitutesOfIndia.InstituteType;

// Extends AbstractInstitute and adds more institute details
public class EducationalInstitute extends AbstractInstitute {
    private String city;
    private StateUT stUt;
    private String nameOfAct;
    private String adminDpt;
    private InstituteType instituteType;

    // Constructor
    public EducationalInstitute(int sno, String instituteName, String city, StateUT stUt, String nameOfAct, String adminDpt, InstituteType instituteType) {
        super(sno, instituteName);
        this.city = city;
        this.stUt = stUt;
        this.nameOfAct = nameOfAct;
        this.adminDpt = adminDpt;
        this.instituteType = instituteType;
    }

    // Copy Constructor
    public EducationalInstitute(EducationalInstitute institute) {
        super(institute.sno, institute.getInstituteName());
        this.city = institute.city;
        this.stUt = institute.stUt;
        this.nameOfAct = institute.nameOfAct;
        this.adminDpt = institute.adminDpt;
        this.instituteType = institute.instituteType;
    }

    // Overridden method to show details
    @Override
    public void showInstituteDetails() {
        System.out.println("Institute: " + getInstituteName() + " - Type: " + instituteType + " - Location: " + city + ", " + stUt);
    }

    // Overloaded method for adding institute type
    public void setInstituteType(InstituteType type) {
        this.instituteType = type;
    }

    public void setInstituteType(String typeName) {
        this.instituteType = InstituteType.valueOf(typeName.toUpperCase());
    }

    // Getters and setters...
}
